REMISIONES ZAVALA — PROTOTIPO WEB

1. Abra index.html en un navegador de escritorio para probar la aplicación.
2. La información se guarda automáticamente en el almacenamiento local del navegador.
3. Cada nota tiene 25 renglones y calcula Cantidad × Precio y el total general.
4. Puede mantener varias notas abiertas, buscarlas y cambiar entre ellas.
5. “Imprimir / PDF” usa la impresión del navegador y está preparado para media carta vertical.

Para instalarla como app en iPhone de forma permanente conviene publicarla en un dominio HTTPS.
